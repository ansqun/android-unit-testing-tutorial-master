package com.chriszou.auttutorial.test.groupshare;

/**
 * Created by xiaochuang on 4/25/16.
 */
public @interface JSpec {

    String desc() default "";
}
