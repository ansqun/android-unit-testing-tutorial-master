package com.chriszou.auttutorial.dagger2;

/**
 * Created by xiaochuang on 5/10/16.
 */
public interface UserApiService {
}
