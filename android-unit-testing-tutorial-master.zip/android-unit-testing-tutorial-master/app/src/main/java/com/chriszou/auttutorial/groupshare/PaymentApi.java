package com.chriszou.auttutorial.groupshare;

import java.util.Map;

/**
 * 底层的一个封装了用户认证等信息的api
 * Created by xiaochuang on 4/25/16.
 */
public class PaymentApi {
    public void get(String url, Map<String, String> params, NetworkCallback callback) {

    }
}
