package com.chriszou.auttutorial.what;

/**
 * Created by xiaochuang on 4/25/16.
 */
public class LoginResult {
    public final boolean successful;

    public LoginResult(boolean successful) {
        this.successful = successful;
    }
}
