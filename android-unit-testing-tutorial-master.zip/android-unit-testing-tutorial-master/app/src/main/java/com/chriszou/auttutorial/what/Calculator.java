package com.chriszou.auttutorial.what;

/**
 * Created by xiaochuang on 4/12/16.
 */
public class Calculator {
    public int add(int one, int another) {
        return one + another;
    }
}
